<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package IBSI
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- <meta name="description" content="An impressive and flawless site template that includes various UI elements and countless features, attractive ready-made blocks and rich pages, basically everything you need to create a unique and professional website."> -->
  <!-- <meta name="keywords" content="bootstrap 5, business, corporate, creative, gulp, marketing, minimal, modern, multipurpose, one page, responsive, saas, sass, seo, startup, html5 template, site template"> -->
  
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <!-- font-awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->

  <meta name="author" content="elemis">
  <title>IBSI - Home</title>
  <link rel="shortcut icon" href="<?= site_url('assets/img/favicon.png') ?>">
  <link rel="stylesheet" href="<?= site_url('assets/css/plugins.css')?> ">
  <link rel="stylesheet" href="<?= site_url('assets/css/style.css')?> ">

	<?php wp_head(); ?>
</head>
<style>
    .mb-xl-24{
      margin-bottom: 0px !important;
    }

    .pt-md-17{
      padding-top: 0rem !important;
    }

    .py-md-18 {
    padding-top: 4rem!important;
    padding-bottom: 4rem!important;
}


.navbar-brand a {
    font-size: 42px;
    letter-spacing: 5px;
    color: #fff;
    font-family: fantasy;
}
  </style>

<body <?php body_class(); ?>>		
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary">
    <?php esc_html_e( 'Skip to content', 'ibsi' ); ?></a>
    <div class="content-wrapper">
      <header class="wrapper bg-soft-primary">
        <nav class="navbar navbar-expand-lg center-nav transparent position-absolute navbar-dark caret-none">
          <div class="container flex-lg-row flex-nowrap align-items-center">
            <div class="navbar-brand w-100">
              <a href="<?= site_url() ?>">
                IBSI
                <!-- <img class="logo-dark" src="assets/img/logo.png" srcset="./assets/img/logo@2x.png 2x" alt="" />
                <img class="logo-light" src="assets/img/logo-light.png" srcset="./assets/img/logo-light@2x.png 2x" alt="" /> -->
              </a>
            </div>
            <div
              class="navbar-collapse offcanvas offcanvas-nav offcanvas-start"
            >
              <div class="offcanvas-header d-lg-none">
                <h3 class="fs-30 mb-0" style="color: #fff">IBSI</h3>
                <button
                  type="button"
                  class="btn-close btn-close-white"
                  data-bs-dismiss="offcanvas"
                  aria-label="Close"
                ></button>
              </div>
              <div class="offcanvas-body ms-lg-auto d-flex flex-column h-100">
                <ul class="navbar-nav">
                  <li class="nav-item dropdown">
                    <a
                      class="nav-link"
                      href="<?= site_url() ?>"
                      >Home</a
                    >
                  </li>

                  <li class="nav-item dropdown">
                    <a
                      class="nav-link"
                      href="<?= site_url('services') ?>"
                     
                      >Services</a>
                  </li>

                  <li class="nav-item dropdown">
                    <a
                      class="nav-link"
                      href="<?= site_url('blog') ?>"
                   
                      >Blog</a
                    >
                  </li>

                  <li class="nav-item dropdown">
                    <a
                      class="nav-link"
                      href="<?= site_url('client') ?>"
                     
                      >Clients</a
                    >
                  </li>

                  <li class="nav-item dropdown dropdown-mega">
                    <a
                      class="nav-link"
                      href="<?= site_url('about') ?>"
                     
                      >About Us</a
                    >
                  </li>
                  <li class="nav-item dropdown dropdown-mega">
                    <a
                      class="nav-link"
                      href="<?= site_url('contact') ?>"
                      
                      >Contact us</a
                    >
                  </li>
                </ul>
                <!-- /.navbar-nav -->
                <div class="offcanvas-footer d-lg-none">
                  <div>
                    <a
                      href="cdn-cgi/l/email-protection.html#86e0eff4f5f2a8eae7f5f2c6e3ebe7efeaa8e5e9eb"
                      class="link-inverse"
                      ><span
                        class="__cf_email__"
                        data-cfemail="167f78707956737b777f7a3875797b"
                        >[email&#160;protected]</span
                      ></a
                    >
                    <br />
                    00 (123) 456 78 90 <br />
                    <nav class="nav social social-white mt-4">
                      <a href="#"><i class="uil uil-twitter"></i></a>
                      <a href="#"><i class="uil uil-facebook-f"></i></a>
                      <a href="#"><i class="uil uil-dribbble"></i></a>
                      <a href="#"><i class="uil uil-instagram"></i></a>
                      <a href="#"><i class="uil uil-youtube"></i></a>
                    </nav>
                    <!-- /.social -->
                  </div>
                </div>
                <!-- /.offcanvas-footer -->
              </div>
              <!-- /.offcanvas-body -->
            </div>
            <!-- /.navbar-collapse -->
            <div class="navbar-other w-100 d-flex ms-auto">
              <ul class="navbar-nav flex-row align-items-center ms-auto">
                <li class="nav-item">
                  <a
                    class="nav-link"
                    data-bs-toggle="offcanvas"
                    data-bs-target="#offcanvas-info"
                    ><i class="uil uil-info-circle"></i
                  ></a>
                </li>
                <li class="nav-item">
                  <a
                    class="nav-link"
                    data-bs-toggle="offcanvas"
                    data-bs-target="#offcanvas-search"
                    ><i class="uil uil-search"></i
                  ></a>
                </li>
                <li class="nav-item d-lg-none">
                  <button class="hamburger offcanvas-nav-btn">
                    <span></span>
                  </button>
                </li>
              </ul>
              <!-- /.navbar-nav -->
            </div>
            <!-- /.navbar-other -->
          </div>
          <!-- /.container -->
        </nav>
        <!-- /.navbar -->
        <div
          class="offcanvas offcanvas-end text-inverse"
          id="offcanvas-info"
          data-bs-scroll="true"
        >
          <div class="offcanvas-header">
            <h3 class="text-white fs-30 mb-0">IBSI</h3>
            <button
              type="button"
              class="btn-close btn-close-white"
              data-bs-dismiss="offcanvas"
              aria-label="Close"
            ></button>
          </div>
          <div class="offcanvas-body pb-6">
            <div class="widget mb-8">
              <p>
                IBSI is a multipurpose HTML5 template with various layouts which
                will be a great solution for your business.
              </p>
            </div>
            <!-- /.widget -->
            <div class="widget mb-8">
              <h4 class="widget-title text-white mb-3">Contact Info</h4>
              <address>
                Moonshine St. 14/05 <br />
                Light City, London
              </address>
              <a
                href="cdn-cgi/l/email-protection.html#b8ded1cacbcc96d4d9cbccf8ddd5d9d1d496dbd7d5"
                ><span
                  class="__cf_email__"
                  data-cfemail="046d6a626b446169656d682a676b69"
                  >[email&#160;protected]</span
                ></a
              ><br />
              00 (123) 456 78 90
            </div>
            <!-- /.widget -->
            <div class="widget mb-8">
              <h4 class="widget-title text-white mb-3">Learn More</h4>
              <ul class="list-unstyled">
                <li><a href="#">Our Story</a></li>
                <li><a href="#">Terms of Use</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Contact Us</a></li>
              </ul>
            </div>
            <!-- /.widget -->
            <div class="widget">
              <h4 class="widget-title text-white mb-3">Follow Us</h4>
              <nav class="nav social social-white">
                <a href="#"><i class="uil uil-twitter"></i></a>
                <a href="#"><i class="uil uil-facebook-f"></i></a>
                <a href="#"><i class="uil uil-dribbble"></i></a>
                <a href="#"><i class="uil uil-instagram"></i></a>
                <a href="#"><i class="uil uil-youtube"></i></a>
              </nav>
              <!-- /.social -->
            </div>
            <!-- /.widget -->
          </div>
          <!-- /.offcanvas-body -->
        </div>
        <!-- /.offcanvas -->
        <div
          class="offcanvas offcanvas-top bg-light"
          id="offcanvas-search"
          data-bs-scroll="true"
        >
          <div class="container d-flex flex-row py-6">
            <form class="search-form w-100">
              <input
                id="search-form"
                type="text"
                class="form-control"
                placeholder="Type keyword and hit enter"
              />
            </form>
            <!-- /.search-form -->
            <button
              type="button"
              class="btn-close"
              data-bs-dismiss="offcanvas"
              aria-label="Close"
            ></button>
          </div>
          <!-- /.container -->
        </div>
        <!-- /.offcanvas -->
      </header>
	</div>
      <!-- /header -->
