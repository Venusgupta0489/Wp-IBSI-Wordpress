<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package sahiadvisory
 */

get_header();
?>
<style>
    .wp-block-search .wp-block-search__label {
    width: auto;
}
</style>

<section class="banner_Section" style="background-image: url(<?= get_field('breadcrumb_bg_image')['url'] ?>);">
	<div class="container">
	    <div class="content_Section">
	    	<div class="content">
	    		<?php if (get_field('breadcrumb_title')): ?>
	    			<h2><?= get_field('breadcrumb_title') ?></h2>
	    	    <?php endif ?>
				<div class="breadcrumb">
					<a href="<?= site_url() ?>" rel="nofollow">Home</a>
					&nbsp;&nbsp;»&nbsp;&nbsp;
					<a href="<?= site_url('blog') ?>">Blog</a>				
					&nbsp;&nbsp;»&nbsp;&nbsp;
					<?= get_field('breadcrumb_title') ?>
				</div>
	    	</div>
	    </div>
    </div>
</section>

<main id="primary" class="site-main">
		<div class="blog-full-cover single-blog-page">
			<div class="container">
				<div class="row">
					<div class="col-lg-8">

						<?php
						while ( have_posts() ) :
							the_post();

							get_template_part( 'template-parts/content', get_post_type() );

							the_post_navigation(
								array(
									'prev_text' => '<span class="nav-subtitle"><i class="fas fa-angle-double-left"></i>' . esc_html__( '', 'screening-buckets' ) . '</span> <span class="nav-title">%title</span>',
									'next_text' => '<span class="nav-subtitle">' . '' . '</span> <span class="nav-title">%title</span><i class="fas fa-angle-double-right"></i>'.esc_html__( '', 'screening-buckets' ),
								)
							);

							// If comments are open or we have at least one comment, load up the comment template.
							

						endwhile; // End of the loop.
						?>

					</div>
					<div class="col-lg-4"><?php get_sidebar(); ?></div>
					
				</div>
			</div>
		</div>

	</main><!-- #main -->

<?php
//get_sidebar();
get_footer();
