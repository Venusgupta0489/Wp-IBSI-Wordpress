<?php
/**
 * IBSI functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package IBSI
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function ibsi_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on IBSI, use a find and replace
		* to change 'ibsi' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'ibsi', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'ibsi' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'ibsi_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'ibsi_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function ibsi_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'ibsi_content_width', 640 );
}
add_action( 'after_setup_theme', 'ibsi_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function ibsi_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'ibsi' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'ibsi' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'ibsi_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function ibsi_scripts() {
	wp_enqueue_style( 'ibsi-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_style_add_data( 'ibsi-style', 'rtl', 'replace' );

	wp_enqueue_script( 'ibsi-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ibsi_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}






/** ----------- THIS FUNCTION ADDED FOR COMMON BREADCRUMB FOR EVERY PAGE ------------
 * Generate breadcrumbs
 * @author CodexWorld
 * @authorURL www.codexworld.com
 */
function get_breadcrumb() {
    echo '<a href="'.home_url().'" rel="nofollow">Home</a>';
    if (is_category() || is_single()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
        
        the_category(' &bull; ');
            if (is_single()) {
                echo " &nbsp;&nbsp;&#187;&nbsp;&nbsp; ";
                the_title();
            }
    } elseif (is_page()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
        the_title();
    } elseif (is_search()) {
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;Search Results for... ";
        echo '"<em>';
        echo the_search_query();
        echo '</em>"';
    }else{
        echo "&nbsp;&nbsp;&#187;&nbsp;&nbsp;";
        echo get_the_title(get_queried_object_id());
    }
}






//  <<<<<<<<-----------------Allow SVG IMAGES TO WEBSITE ------------>>>>>>>>>>







/** <<<<<<<<<<<<--------- CUSTOM NAV MENU ------------->>>>>>>>>>>>> */

require get_template_directory() . '/inc/nav-test-menu-template.php';






//  <<<<<<<<<<<-------------------------- ADDING CUSTOM BLOCKS --------------------------->>>>>>>>>

add_action('acf/init', 'hero_section');
function hero_section() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'Tab section',
            'title'             => __('hero_section'),
            'description'       => __('A custom hero section block.'),
            'render_template'   => 'template-parts/block/hero_section/hero.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/hero_section/style.css',  
        ));
    }
}

add_action('acf/init', 'about_section');
function about_section() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'about_section',
            'title'             => __('about_section'),
            'description'       => __('A custom about_section block.'),
            'render_template'   => 'template-parts/block/about_section/about.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/about_section/style.css',  
        ));
    }
}

add_action('acf/init', 'usp_section');
function usp_section() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'usp_section',
            'title'             => __('usp_section'),
            'description'       => __('A custom usp_section block.'),
            'render_template'   => 'template-parts/block/usp_section/usp.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/usp_section/style.css',  
        ));
    }
}

add_action('acf/init', 'banner_section');
function banner_section() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'banner_section',
            'title'             => __('banner_section'),
            'description'       => __('A custom banner_section block.'),
            'render_template'   => 'template-parts/block/banner_section/banner.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/banner_section/style.css',  
        ));
    }
}

add_action('acf/init', 'testimonial_section');
function testimonial_section() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'testimonial_section',
            'title'             => __('testimonial_section'),
            'description'       => __('A custom testimonial_section block.'),
            'render_template'   => 'template-parts/block/testimonial_section/testimonial.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/testimonial_section/style.css',  
        ));
    }
}

add_action('acf/init', 'services_section');
function services_section() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'services_section',
            'title'             => __('services_section'),
            'description'       => __('A custom services_section block.'),
            'render_template'   => 'template-parts/block/services_section/services.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/services_section/style.css',  
        ));
    }
}

add_action('acf/init', 'left_image_right_content');
function left_image_right_content() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'left_image_right_content',
            'title'             => __('left_image_right_content section'),
            'description'       => __('A custom left_image_right_content block.'),
            'render_template'   => 'template-parts/block/left_image_right_content/leftcontent.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/left_image_right_content/style.css',  
        ));
    }
}

add_action('acf/init', 'call_to_action');
function call_to_action() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'call_to_action',
            'title'             => __('call_to_action section'),
            'description'       => __('A custom call_to_action block.'),
            'render_template'   => 'template-parts/block/call_to_action/calltoaction.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/call_to_action/style.css',  
        ));
    }
}

add_action('acf/init', 'client_section');
function client_section() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'client_section',
            'title'             => __('client_section'),
            'description'       => __('A custom client_section block.'),
            'render_template'   => 'template-parts/block/client_section/client.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/client_section/style.css',  
        ));
    }
}

add_action('acf/init', 'faq_section');
function faq_section() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'faq_section',
            'title'             => __('faq_section'),
            'description'       => __('A custom faq_section block.'),
            'render_template'   => 'template-parts/block/faq_section/faq.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/faq_section/style.css',  
        ));
    }
}

add_action('acf/init', 'contact_section');
function contact_section() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'contact_section',
            'title'             => __('contact_section'),
            'description'       => __('A custom contact_section block.'),
            'render_template'   => 'template-parts/block/contact_section/contact.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/contact_section/style.css',  
        ));
    }
}

add_action('acf/init', 'bread_crumb');
function bread_crumb() {

    // Check function exists.
    if( function_exists('acf_register_block_type') ) {

        // register a testimonial block.
        acf_register_block_type(array(
            'name'              => 'bread_crumb',
            'title'             => __('bread_crumb'),
            'description'       => __('A custom bread_crumb block.'),
            'render_template'   => 'template-parts/block/bread_crumb/breadcrumb.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'enqueue_style' => get_template_directory_uri() . '/template-parts/block/bread_crumb/style.css',  
        ));
    }
}