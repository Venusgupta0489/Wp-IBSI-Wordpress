<section id="snippet-3" class="wrapper bg-light wrapper-border">
      <div class="container pt-15 pt-md-17 pb-13 pb-md-15">
        <h2 class="display-4 mb-3 text-center">Pricing FAQ</h2>
        <p class="lead text-center mb-10 px-md-16 px-lg-0">If you don't see an answer to your question, you can send us an email from our contact form.</p>
        <div class="row">
          <div class="col-lg-6 mb-0">

          <?php  if(!empty(get_field('faq_bar'))){ ?>
            <div id="accordion-1" class="accordion-wrapper">
                <?php $i=1; foreach(get_field('faq_bar') as $value){ 
                  if($i <= 4){?>
                    <div class="card accordion-item">
                        <div class="card-header" id="accordion-heading-1-<?= $i; ?>">
                            <button class="<?php if($i==1){ echo "accordion-button"; }else{ echo "collapsed"; } ?>" data-bs-toggle="collapse" data-bs-target="#accordion-collapse-1-<?= $i; ?>" aria-expanded="false" aria-controls="accordion-collapse-1-<?= $i; ?>"><?= $value['title']?></button>
                        </div>
                     
                        <div id="accordion-collapse-1-<?= $i; ?>" class="collapse <?php if($i==1){ echo "show"; } ?>" aria-labelledby="accordion-heading-1-<?= $i; ?>" data-bs-target="#accordion-1">
                            <div class="card-body">
                                <p><?= $value['content']?></p>
                            </div>
                        </div>
                    </div>
                    
                <?php $i++; } }?>
            </div>
            <?php } ?>
          </div>
          <div class="col-lg-6 mb-0">
          
          </div>
         </div>
       </div>
</section>
          