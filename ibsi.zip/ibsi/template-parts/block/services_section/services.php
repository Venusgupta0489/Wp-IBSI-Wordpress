<section class="wrapper bg-light" style="padding-bottom: 4rem">
        <div class="container pt-14 pt-md-12">
          <div class="row text-center">
            <div class="col-md-10 offset-md-1 col-lg-8 offset-lg-2">
              <h2 class="fs-16 text-uppercase text-muted mb-3"><?= get_field('heading') ?></h2>
              <h3 class="display-4 mb-10 px-xl-10"><?= get_field('sub_heading') ?></h3>
            </div>
            <!-- /column -->
          </div>
          <!-- /.row -->
          <div class="position-relative">
            <div
              class="shape rounded-circle bg-soft-blue rellax w-16 h-16"
              data-rellax-speed="1"
              style="bottom: -0.5rem; right: -2.2rem; z-index: 0">
            </div>
            <div
              class="shape bg-dot primary rellax w-16 h-17"
              data-rellax-speed="1"
              style="top: -0.5rem; left: -2.5rem; z-index: 0"
            ></div>
            <div class="row gx-md-5 gy-5 text-center">
            <?php foreach(get_field('service_repeater') as $value) { ?>
              <div class="col-md-6 col-xl-3">
                <div class="card shadow-lg">
                  <div class="card-body">
                    <img
                      src="<?= $value['image']['url'] ?>"
                      class="svg-inject icon-svg icon-svg-md text-yellow mb-3"
                      alt=""
                    />
                    <h4><?= $value['title'] ?></h4>
                    <p class="mb-2"><?= $value['description'] ?></p>
                    <a href="<?= $value['learn_more'] ?>" class="more hover link-yellow">Learn More</a>
                  </div>
                  <!--/.card-body -->
                </div>
                <!--/.card -->
              </div>
              <?php } ?>
              <!--/column -->

            </div>
            <!--/.row -->
          </div>
          <!-- /.position-relative -->
        </div>
        <!-- /.container -->
      </section>