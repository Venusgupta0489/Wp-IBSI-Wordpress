<style>
  .wrapper input{
    height: 50px !important;
  }
  .wrapper select{
    height: 50px !important;
  }
</style>
<section class="wrapper bg-light">
      <div class="container pb-10 pt-14">

        <!-- /.row -->
        <div class="row">
          <div class="col-xl-10 mx-auto">
            <div class="row gy-10 gx-lg-8 gx-xl-12">

              <div class="col-lg-8">
                <form class="contact-form needs-validation" method="post" action="https://sandbox.elemisthemes.com/assets/php/contact.php" novalidate>
                  <div class="row gx-4">
                  <!-- <div class="right-contact-page"> -->
                        <?php echo do_shortcode(get_field('enquiry_form')); ?>
                  <!-- </div> -->
                  </div>
                </form>
              </div>

              <div class="col-lg-4">
                <?php foreach(get_field('address_detail_repeater') as $value) { ?>
                  <div class="d-flex flex-row">
                    <div>
                      <div class="icon text-primary fs-28 me-4 mt-n1"> <?= $value['icon'] ?></div>
                    </div>
                    <div>
                      <h5 class="mb-1"><?= $value['title'] ?></h5>
                      <address><?= $value['description'] ?></address>
                    </div>
                  </div>
                <?php } ?>
              </div>

            </div>
          </div>
        </div>
      </div>
</section>
    <!-- /section -->

    <section class="wrapper bg-light">
      <div class="map">
        <iframe src="<?php echo get_field('map') ?>" style="width:100%; height: 500px; border:0" allowfullscreen></iframe>
      </div>
      <!-- /.map -->
    </section>
