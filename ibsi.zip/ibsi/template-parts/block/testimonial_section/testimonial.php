<section class="wrapper bg-gradient-reverse-primary">
        <div class="container py-14 py-md-18">
          <div class="row gx-lg-8 gx-xl-12 gy-10 align-items-center">
            <div class="col-lg-7">
              <div class="row gx-md-5 gy-5">
                <div class="col-md-6 col-xl-5 align-self-end">
                  <div class="card shadow-lg">
                    <div class="card-body">
                      <blockquote class="icon mb-0">
                        <p><?= get_field('testimonial_repeater')[0]['comments'] ?></p>
                        <div class="blockquote-details">
                          <div class="info p-0">
                            <h5 class="mb-1"><?= get_field('testimonial_repeater')[0]['name'] ?></h5>
                            <p class="mb-0"><?= get_field('testimonial_repeater')[0]['designation'] ?></p>
                          </div>
                        </div>
                      </blockquote>
                    </div>
                    <!--/.card-body -->  
                  </div>
                  <!--/.card -->
                </div>
                <!--/column -->

                <div class="col-md-6 align-self-end">
                  <div class="card shadow-lg">
                    <div class="card-body">
                      <blockquote class="icon mb-0">
                        <p>
                        <?= get_field('testimonial_repeater')[1]['comments'] ?>
                        </p>
                        <div class="blockquote-details">
                          <div class="info p-0">
                            <h5 class="mb-1"><?= get_field('testimonial_repeater')[1]['name'] ?></h5>
                            <p class="mb-0"><?= get_field('testimonial_repeater')[1]['designation'] ?></p>
                          </div>
                        </div>
                      </blockquote>
                    </div>
                    <!--/.card-body -->
                  </div>
                  <!--/.card -->
                </div>
                <!--/column -->

                <div class="col-md-6 col-xl-5 offset-xl-1">
                  <div class="card shadow-lg">
                    <div class="card-body">
                      <blockquote class="icon mb-0">
                        <p>
                        <?= get_field('testimonial_repeater')[2]['comments'] ?>
                        </p>
                        <div class="blockquote-details">
                          <div class="info p-0">
                            <h5 class="mb-1"><?= get_field('testimonial_repeater')[2]['name'] ?></h5>
                            <p class="mb-0"><?= get_field('testimonial_repeater')[2]['designation'] ?></p>
                          </div>
                        </div>
                      </blockquote>
                    </div>
                    <!--/.card-body -->
                  </div>
                  <!--/.card -->
                </div>
                <!--/column -->

                <div class="col-md-6 align-self-start">
                  <div class="card shadow-lg">
                    <div class="card-body">
                      <blockquote class="icon mb-0">
                        <p>
                        <?= get_field('testimonial_repeater')[3]['comments'] ?>
                        </p>
                        <div class="blockquote-details">
                          <div class="info p-0">
                            <h5 class="mb-1"><?= get_field('testimonial_repeater')[3]['name'] ?></h5>
                            <p class="mb-0"><?= get_field('testimonial_repeater')[3]['designation'] ?></p>
                          </div>
                        </div>
                      </blockquote>
                    </div>
                    <!--/.card-body -->
                  </div>
                  <!--/.card -->
                </div>
                <!--/column -->

              </div>
              <!--/.row -->
            </div>
            <!--/column -->
            <div class="col-lg-5">
              <h2 class="fs-16 text-uppercase text-muted mb-3 mt-lg-n6">
                <?= get_field('heading') ?>
              </h2>
              <h3 class="display-4 mb-5">
                <?= get_field('sub_heading') ?>
              </h3>
              <p>
                <?= get_field('description') ?>
              </p>
              <a href="get_field('button')" class="btn btn-primary rounded-pill mt-3">All Testimonials</a>
            </div>
            <!--/column -->
          </div>
          <!--/.row -->
        </div>
        <!-- /.container -->
      </section>