<section id="snippet-4" class="wrapper bg-light wrapper-border">
        <div class="container pt-15 pt-md-17 pb-13 pb-md-15">
          <!--/.row -->
          <div class="row text-center">
            <div class="col-lg-9 mx-auto">
              <h2 class="fs-15 text-uppercase text-muted mb-3 mt-12">
                <?= get_field('heading') ?>
              </h2>
              <h3 class="display-4 mb-0 text-center px-xl-10 px-xxl-15">
                <?= get_field('sub-heading') ?>
              </h3>
              <div class="row gx-lg-8 gx-xl-12 process-wrapper text-center mt-10">

              <?php foreach(get_field('usp_repeater') as $value) { ?>
                <div class="col-md-4">
                  <img src="<?= $value['icon']['url'] ?>"
                    class="svg-inject icon-svg icon-svg-md text-primary mb-3"
                    alt="" />
                  <h4 class="mb-1"><?= $value['title'] ?></h4>
                  <p class="mb-0"><?= $value['description'] ?></p>
                </div>
                <?php } ?>

                <!--/column -->
              </div>
              <!--/.row -->
            </div>
            <!-- /column -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container -->
        <!-- /.container -->
      </section>