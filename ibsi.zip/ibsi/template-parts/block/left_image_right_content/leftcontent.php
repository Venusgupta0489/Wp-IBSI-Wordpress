<style>
    .accordion-button:not(.collapsed)::after ,.accordion-button::after{
        display:none;
    }
    
    .accordion-button:not(.collapsed) {
        box-shadow: none !important;
    }
</style>
<section class="wrapper bg-gray">
        <div class="container py-14 py-md-10">
          <div class="row gx-lg-8 gx-xl-12 gy-10 mb-14 mb-md-7 align-items-center">
            <div class="col-lg-7 <?php if(get_field('reverce')){ echo "order-2 reverce"; } ?>">
                <img src="<?= get_field('left_image')['url'] ?>" class="img-fluid">
                <?php /*
                  <figure><img class="w-auto" src="<?= get_field('left_image')['url'] ?>" srcset="./assets/img/illustrations/i3@2x.png 2x" alt="" /></figure>
               */?>
            </div>
            <div class="col-lg-5">
              <h2 class="fs-15 text-uppercase text-line text-primary mb-3"><?= get_field('heading') ?></h2>
              <h3 class="display-5 mb-7 pe-xxl-5"><?= get_field('sub_heading') ?></h3>
              <?php if(!empty(get_field('icon_text_repeater'))){
                foreach(get_field('icon_text_repeater') as $value){ ?>
                        <!-- service section -->
                        <div class="d-flex flex-row mb-4">
                            <div>
                                <img src="<?= $value['icon']['url'] ?>" class="svg-inject icon-svg icon-svg-sm text-blue me-4" alt="" />
                            </div>
                            <div>
                                <h4 class="mb-1"><?= $value['title'] ?></h4>
                                <p class="mb-1"><?= $value['short_desc'] ?></p>
                            </div>
                        </div>
              <?php } }?>
              <!-- service section -->

              <!-- Faq section -->
                <?php  if(!empty(get_field('faq_bar'))){ ?>
                    <div class="accordion accordion-wrapper" id="accordionExample">
                      <?php $i=1; foreach(get_field('faq_bar') as $value){  ?>
                            <div class="card plain accordion-item">
                                <div class="card-header" id="heading<?= $i; ?>">
                                    <button class="<?php if($i==1){ echo "accordion-button"; }else{ echo "collapsed"; } ?>" 
                                    data-bs-toggle="collapse" data-bs-target="#collapse<?= $i; ?>" aria-expanded="true" aria-controls="collapse<?= $i; ?>"> <?= $value['title']?> </button>
                                </div>
                                <div id="collapse<?= $i; ?>" class="accordion-collapse collapse <?php if($i==1){ echo "show"; } ?>" aria-labelledby="heading<?= $i; ?>" data-bs-parent="#accordionExample">
                                    <div class="card-body">
                                    <p><?= $value['content']?></p>
                                    </div>
                                </div>
                            </div>
                            <?php $i++; } ?>
                    </div>
                <?php } ?>
              <!-- Faq section -->
            </div>
          </div>
        </div>
</section>
