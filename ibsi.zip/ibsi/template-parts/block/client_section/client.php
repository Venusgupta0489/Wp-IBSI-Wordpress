

    <section id="snippet-2" class="wrapper bg-light wrapper-border">
        <div class="container pt-15 pb-13 pb-md-11">
          <div class="row gx-lg-8 gx-xl-12 gy-10 gy-lg-0">
            <div class="col-lg-4 mt-lg-2">
              <h2 class="fs-15 text-uppercase text-muted mb-3"><?= get_field('heading') ?></h2>
              <h3 class="display-4 mb-3 pe-xxl-5"><?= get_field('sub_heading') ?></h3>
              <p class="lead fs-lg mb-0 pe-xxl-5"><?= get_field('short_desc') ?></p>
            </div>
            <!-- /column -->
            <div class="col-lg-8">
              <div class="row row-cols-2 row-cols-md-4 gx-0 gx-md-8 gx-xl-12 gy-12">
                <?php foreach(get_field('client_repeater') as $value) { ?>
                <div class="col">
                  <figure class="px-3 px-md-0 px-xxl-2"><img src="<?= $value['img']['url'] ?>" alt="" /></figure>
                </div>
                <?php } ?>
                <!--/column -->
              </div>
              <!--/.row -->
            </div>
            <!-- /column -->
          </div>
        </div>
    </section>