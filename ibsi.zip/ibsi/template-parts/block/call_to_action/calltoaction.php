<section id="snippet-2" class="wrapper bg-light wrapper-border">
      <div class="container pt-15 pt-md-17 pb-13 pb-md-15">
        <div class="row">
          <div class="col-xl-10 mx-auto">
            <div class="card image-wrapper bg-full bg-overlay bg-overlay-400" style="background-image: url('<?= get_field('bg_image')['url'] ?>')">
              <div class="card-body p-6 p-md-11 d-lg-flex flex-row align-items-lg-center justify-content-md-between text-center text-lg-start">
                <h3 class="display-6 mb-6 mb-lg-0 pe-lg-10 pe-xl-5 pe-xxl-18 text-white"><?= get_field('title') ?></h3>
                <a href="<?= get_field('button') ?>" class="btn btn-white rounded-pill mb-0 text-nowrap">Join Us</a>
              </div>
            </div>
          </div>
        </div>
      </div>
</section>