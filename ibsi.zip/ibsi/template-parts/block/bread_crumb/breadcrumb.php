<style>
.breadcrumb {
    background: none !important;
    margin-bottom: 0px!important;
    color: #fff;
    font-size: 14px;
    position: absolute;
    padding: 0px;
}
.breadcrumb a {
    color: #fff;
    font-size: 14px;
}

.banner_Section{
    background-repeat: no-repeat !important;
    background-size: cover !important;
    background-position: center !important;
    position: relative;
    background: #f3f3f3;
    padding: 150px 0px;
}
.banner_Section::before {
    position: absolute;
    content: "";
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    right: 0;
    background-color: #787878;
    opacity: 0.8;
}
.content_Section{
    display: flex;
    justify-content: start;
    align-items: baseline;
}
.content_Section h2{
    color: #fff;
    position: relative;
}
</style>


<section class="banner_Section" style="background-image: url(<?= get_field('breadcrumb_bg_image')['url'] ?>);">
	<div class="container">
	    <div class="content_Section">
	    	<div class="content">
	    		<?php if (get_field('breadcrumb_title')): ?>
	    			<h2><?= get_field('breadcrumb_title') ?></h2>
	    	    <?php endif ?>
				<div class="breadcrumb">
					<?php get_breadcrumb(); ?>
				</div>
	    	</div>
	    </div>
    </div>
</section>