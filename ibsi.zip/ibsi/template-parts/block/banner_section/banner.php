<section class="wrapper image-wrapper bg-overlay" style="background-image: url('<?= get_field('bg_img')['url'] ?>');">
        <div class="container py-18 text-center">
          <div class="row">
            <div class="col-lg-10 col-xl-10 col-xxl-8 mx-auto">
              <a
                href="assets/media/movie.mp4"
                class="btn btn-circle btn-white btn-play ripple mx-auto mb-5"
                data-glightbox
                ><i class="icn-caret-right"></i
              ></a>
              <h2 class="display-4 px-lg-10 px-xl-13 px-xxl-10 text-white">
              <?= get_field('sub-heading') ?>
              </h2>
            </div>
            <!--/column -->
          </div>
          <!--/.row -->
        </div>
        <!-- /.container -->
</section>