<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package sahiadvisory
 */

get_header();
?>
<style>

	.site-main{
		font-family: "Liberation Mono","Courier New",monospace;
	}
    .wp-block-search .wp-block-search__label {
    width: auto !important;
}
	.fa-linkedin:before {
    content: "\f0e1";
    position: relative;
    bottom: 2px;
}
</style>
<section class="banner_Section" style="background-image: url(<?= get_the_post_thumbnail_url(); ?>);">
	<div class="container">
	    <div class="content_Section">
	    	<div class="content">
	    			<h2>Blog</h2>
				<div class="breadcrumb">
					<?php get_breadcrumb(); ?>
				</div>
	    	</div>
	    </div>
    </div>
</section>

	<main id="primary" class="site-main">
		<div class="blog-full-cover">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 mb-13">
						<div class="row">
							
							<?php 
							$args = array( 
								'post_type'   => 'post',
								'posts_per_page' => -1,
								'orderby' => 'date',
				                'order'   => 'DESC',
							);
							$scheduled = new WP_Query( $args );

							if ( $scheduled->have_posts() ) : 
							?>
								<?php $count = 1; while( $scheduled->have_posts() ) : $scheduled->the_post() ?>

								<?php if($count <= 1){ ?>
									<div class="col-lg-6">
										<div class="blog-left-image">
											<a href="<?php echo get_permalink(); ?>">
											<img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid"> </a>
										</div>
									</div>
									<div class="col-lg-6">

										<div class="right-post-inside">
											<div class="tags-posts">
											 <?php
												$posttags = get_the_category(get_the_ID());
												$slug = get_category_link($posttags[0]->term_id);
												if ($posttags) {
												    
												    $listt = "";
												  foreach($posttags as $tag) {
												    $listt .= "<a href='".get_category_link($tag->term_id)."'>".$tag->name . '</a>'; 
												  }
												  
												  echo rtrim($listt, ', ');
												}
												?>
											</div>

											<h1><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h1>
											<p class="date-published"><small><?php echo get_the_date(); ?></small></p>
											<div class="the_excerpt_post-blog">
												<?php echo the_excerpt(); ?>
											</div>

											<div class="share-btnn">
												<!-- AddToAny BEGIN -->
												<a target="_blank" href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>"><i class="fa fa-facebook"></i></a>
												<a target="_blank" href="https://twitter.com/intent/tweet?text=<?php echo get_permalink(); ?>"><i class="fa fa-twitter"></i></a>
												<a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo get_permalink(); ?>"><i class="fa fa-linkedin"></i></a>
												
												<!-- AddToAny END -->
											</div>

										</div>
									</div>
									<?php } ?>

								<?php $count++; endwhile ?>
							<?php else : ?>
								No Post Found...
							<?php endif ?>


						</div>
					</div>

					<div class="col-lg-8">

						<div class="row">
						<?php if ( $scheduled->have_posts() ) : ?>
						<?php $count_new = 1; while( $scheduled->have_posts() ) : $scheduled->the_post() ?>
							
							<?php if($count_new > 1){ ?>
							<div class="col-lg-6">
								<div class="blog-2-2-post">
									
									<div class="blog-left-image">
										<a href="<?php echo get_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" class="img-fluid"> 
										</a>
									</div>

									<div class="tags-posts smalll">
										<?php
												$posttags = get_the_category(get_the_ID());
												$slug = get_category_link($posttags[0]->term_id);
												if ($posttags) {
												    
												    $listt = "";
												  foreach($posttags as $tag) {
												    $listt .= "<a href='".get_category_link($tag->term_id)."'>".$tag->name . '</a>'; 
												  }
												  
												  echo rtrim($listt, ', ');
												}
												?>
									</div>

									<h2><a href="<?php echo get_permalink(); ?>"><?php the_title(); ?></a></h2>

									<p class="date-published"><small><?php echo get_the_date(); ?></small></p>
									<div class="the_excerpt_post-blog mb-4">
										<?php echo substr(get_the_excerpt(), 0,100) ; ?>...
									</div>

									<div class="view-post-and-social">
										<div class="btn-view">
											<a class="btn btn-primary rounded-pill mt-3" href="<?php echo get_permalink(); ?>"><button type="button">View Post</button></a>
										</div>
										<div class="sharebtnnnnn">
											<div class="share-btnn">
												<!-- AddToAny BEGIN -->
												<a target="_blank" href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>"><i class="fa fa-facebook"></i></a>
												<a target="_blank" href="https://twitter.com/intent/tweet?text=<?php echo get_permalink(); ?>"><i class="fa fa-twitter"></i></a>
												<a target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo get_permalink(); ?>"><i class="fa fa-linkedin"></i></a>
												<!-- AddToAny END -->
											
											</div>
										</div>
									</div>

								</div>

							</div>
							<?php } ?>
						<?php $count_new++; endwhile ?>
						
						<?php endif ?>

							
						</div>
						

					</div>

					<div class="col-lg-4">
						<?php get_sidebar(); ?>
					</div>

				</div> <!-- row -->

			</div>
		</div>
	</main><!-- #main -->

<?php

get_footer();
